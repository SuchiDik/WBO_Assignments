package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@EntityScan(basePackages = "com.example.*")
@SpringBootApplication(scanBasePackages = "com.example.*")
@EnableAutoConfiguration
public class OauthResourceServer1Application {

	public static void main(String[] args) {
		SpringApplication.run(OauthResourceServer1Application.class, args);
	}

}
