package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.entity.Message;
import com.example.entity.User;
import com.example.repository.UserRepository;

@Controller
public class HomeController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("home", "Home Page");
		return "home";

	}

	@RequestMapping("/signup")
	public String signup(Model model) {
		model.addAttribute("signup", "Signing up with correct Details");
		return "signup";

	}

	@RequestMapping("/about")
	public String about(Model model) {
		model.addAttribute("title", "Registration");
		return "about";

	}

	@PostMapping("/register")
	public String registerUser(@ModelAttribute("user") User user, Model model, HttpSession session) {
		try {
			System.out.println("USer" + user);
			user.setRole("ROLE_USER");
			user.setEnabled(true);
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			User result = this.userRepository.save(user);
			model.addAttribute("user", new User());
			session.setAttribute("message", new Message("Successfully logged in", "alert-success"));
			return "signup";

		} catch (Exception e) {

			e.printStackTrace();
			model.addAttribute("user", user);
			session.setAttribute("message", new Message("Something went Wrong" + e.getMessage(), "alert-error"));
			return "signup";

		}
	}

}
