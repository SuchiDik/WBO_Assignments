package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
@Table(name = "emp_department")
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Department {

	@Id
	@Column
	private int departmentId;

	@Column
	@NotEmpty
	@Size(min = 5, message = "department name can not empty")
	private String departmentName;

	@Column
	@Size(min = 5, message = "department head name can not empty")
	@NotBlank
	private String departmentHeadName;

}
