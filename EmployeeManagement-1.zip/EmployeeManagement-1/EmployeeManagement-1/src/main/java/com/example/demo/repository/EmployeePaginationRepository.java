package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Employee;

@Repository
public interface EmployeePaginationRepository extends PagingAndSortingRepository<Employee, Integer> {

	Optional<Employee> findByEmployeeId(int employeeId);

	@Query(value = "SELECT employee FROM Employee employee where employee.firstName = ?1 or employee.lastName = ?2 or employee.departmentId = ?3")
	List<Employee> findByFirstNameORDepartmentIdORLastName(String firstName, String lastName, int departmentId,
			Pageable p);

	@Query(value = "SELECT employee FROM Employee employee where employee.firstName = ?1 or employee.lastName = ?2 or employee.departmentId = ?3")

	Optional<Employee> findByFirstNameORDepartmentId(String firstName, String lastName, int departmentId);

}
