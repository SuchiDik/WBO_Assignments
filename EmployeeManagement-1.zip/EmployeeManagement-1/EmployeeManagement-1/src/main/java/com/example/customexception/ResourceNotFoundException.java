package com.example.customexception;

import lombok.Getter;
import lombok.Setter;

@SuppressWarnings("serial")
@Setter
@Getter
public class ResourceNotFoundException extends RuntimeException {

	private final String resourceName;
	private final long fieldValue;
	private final String fieldName;

	public ResourceNotFoundException(String resourceName, String fieldName, long fieldValue) {
		super(String.format("%s not found with %s : %s", resourceName, fieldName, fieldValue));
		this.resourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}

	@Override
	public String toString() {
		return "ErrorResponse [fieldValue=" + fieldValue + ", fieldName=" + fieldName + ", resourceName=" + resourceName
				+ "]";
	}

}
