package com.example.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;

import com.example.customexception.ResourceNotFoundException;
import com.example.demo.entities.Project;
import com.example.demo.entities.ProjectDTO;
import com.example.demo.entities.ProjectDtoConverter;
import com.example.demo.repository.ProjectRepository;

public class ProjectService {

	private final ProjectRepository projectRepository;
	private final ProjectDtoConverter projectDtoConverter;

	Logger logger = LoggerFactory.getLogger(ProjectService.class);

	public ProjectService(ProjectRepository projectRepository2,ProjectDtoConverter projectDtoConverter) {
		this.projectRepository = projectRepository2;
		this.projectDtoConverter = projectDtoConverter;
	}

	public ProjectService(ProjectDtoConverter projectDtoConverter) {
		this.projectRepository = null;
		this.projectDtoConverter = projectDtoConverter;
	}

	@Cacheable(cacheNames = "project", key = "#projectId")
	public Project findByProjectId(int projectId) {
		return projectRepository.findByProjectId(projectId)
				.orElseThrow(() -> new ResourceNotFoundException("Project", "Id", projectId));

	}

	public ProjectDTO saveProjectDetails(ProjectDTO projectDto) {
		Project project = projectDtoConverter.convertDtoToEntity(projectDto);
		project = projectRepository.save(project);
		return projectDtoConverter.convertEntityToDto(project);
	}

	@CachePut(cacheNames = "project", key = "#projectId")
	public ProjectDTO updateProjectDetails(ProjectDTO projectDto, int projectId) {
		Project project = projectDtoConverter.convertDtoToEntity(projectDto);
		project = projectRepository.findByProjectId(projectId)
				.orElseThrow(() -> new ResourceNotFoundException("ProjectDTO", "Id", projectId));
		project.setClientName(projectDto.getClientName());
		project.setLastPromotionDate(projectDto.getLastPromotionDate());
		project.setProjectName(projectDto.getProjectName());
		project.setStatus(projectDto.getStatus());
		project.setProjectStartDate(projectDto.getProjectStartDate());
		project = projectRepository.save(project);
		return projectDtoConverter.convertEntityToDto(project);

	}

	public List<Project> getProjectDetails() {
		return projectRepository.findAll();
	}

	@CacheEvict(cacheNames = "project", key = "#projectId")
	public String deleteProjectDetails(int projectId) {

		projectRepository.deleteById(projectId);
		return "project Deleted : " + projectId;
	}
}