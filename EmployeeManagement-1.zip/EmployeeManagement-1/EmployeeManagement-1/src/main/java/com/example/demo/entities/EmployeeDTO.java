package com.example.demo.entities;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EmployeeDTO {

	public EmployeeDTO(int employeeId, String firstName, String middleName, String lastName, String email) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.email = email;
	}

	private int employeeId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String email;
	private String phoneNo;
	private String gender;
	private Date dateOfBirth;
	private Date joiningDate;
	private Integer totalExp;
	private String currentLocation;
	private String salary;
	private String designation;
	private Date lastPromotionDate;
	private Date projectAllocationDate;
	private Date resignedDate;
	private Date lastWorkingDate;
	private Integer managerId;
	private int departmentId;
	private int projectId;
	private boolean deleted = Boolean.FALSE;

}
