package com.example.demo.entities;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class EmployeeDtoConverter {

	public EmployeeDTO convertEntityToDto(Employee employee) {
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(employee, EmployeeDTO.class);
	}

	public Employee convertDtoToEntity(EmployeeDTO employeeDTO) {
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(employeeDTO, Employee.class);
	}

}
