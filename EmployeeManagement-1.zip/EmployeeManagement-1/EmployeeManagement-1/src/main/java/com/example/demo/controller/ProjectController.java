package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Project;
import com.example.demo.entities.ProjectDTO;
import com.example.demo.entities.ProjectDtoConverter;
import com.example.demo.service.ProjectService;

@RestController
@RequestMapping("/api/v1")
public class ProjectController {

	private ProjectService projectService;
	private ProjectDtoConverter projectDtoConverter;

	public ProjectController(ProjectService projectService,	ProjectDtoConverter projectDtoConverter) {
		this.projectService = projectService;
		this.projectDtoConverter=projectDtoConverter;
	}

	Logger logger = LoggerFactory.getLogger(ProjectController.class);

	@GetMapping(path = "/projects")
	public ResponseEntity<List<Project>> getProjectDetails() {
		logger.debug("find all");
		return ResponseEntity.ok(projectService.getProjectDetails());

	}

	@PostMapping(path = "/project")
	@ResponseBody
	public ResponseEntity<ProjectDTO> saveProjectDetails(@Valid @RequestBody ProjectDTO projectDto) {
		logger.info("In save project:{}", projectDto);
		return new ResponseEntity<>(projectService.saveProjectDetails(projectDto), HttpStatus.CREATED);
	}

	@GetMapping("/project/{projectId}")
	public ResponseEntity<Project> findByProjectId(@PathVariable int projectId) {
		logger.info("In get deptController:{}", projectId);
		return ResponseEntity.ok(projectService.findByProjectId(projectId));

	}

	@DeleteMapping("/project/{projectId}")
	public ResponseEntity<String> deleteProjectDetails(@PathVariable int projectId) {
		logger.info("In delete project:{}", projectId);

		return ResponseEntity.ok(projectService.deleteProjectDetails(projectId));
	}

	@PatchMapping("/project/{projectId}")
	public ResponseEntity<ProjectDTO> updateProjectDetails(@Valid @RequestBody ProjectDTO projectDto,
			@PathVariable int projectId) {
		logger.info("In update project:{}", projectId);

		return ResponseEntity.ok(projectService.updateProjectDetails(projectDto, projectId));

	}

}
