package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.Employee;
import com.example.demo.entities.EmployeeDTO;
import com.example.demo.entities.EmployeeDtoConverter;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {

	private EmployeeService employeeService;
	private EmployeeDtoConverter employeedtoConverter;

	public EmployeeController(EmployeeService employeeService,EmployeeDtoConverter employeedtoConverter) {
		this.employeeService = employeeService;
		this.employeedtoConverter=employeedtoConverter;
	}

	Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	/**
	 * 
	 * @param employerequestmodel
	 * @return //
	 */

	@GetMapping(path = "/employees")
	public ResponseEntity<List<Employee>> getEmployeeDetails() {
		logger.debug("find all");
		return ResponseEntity.ok(employeeService.getEmployeeDetails());

	}

	/**
	 * 
	 * @param employerequestmodel
	 * @return
	 */

	@PostMapping(path = "/employee")
	@ResponseBody
	public ResponseEntity<EmployeeDTO> saveEmployeeDetails(@Valid @RequestBody EmployeeDTO employeeDto) {
		logger.info("In save employee:{}", employeeDto);
		return new ResponseEntity<>(employeeService.saveEmployeeDetails(employeeDto), HttpStatus.CREATED);
	}

	/**
	 * 
	 * @param employeeId
	 * @return
	 */

	@GetMapping("/employee/{employeeId}")
	public ResponseEntity<Employee> findByEmployeeId(@PathVariable int employeeId) {
		logger.info("In get employeeController:{}", employeeId);
		return ResponseEntity.ok(employeeService.findByEmployeeId(employeeId));
	}

	/**
	 * 
	 * @param offset
	 * @param pageSize
	 * @param field
	 * @return
	 */
	@GetMapping("/employee/search")
	public ResponseEntity<Optional<Employee>> findByFirstNameAndDepartmentId(
			@RequestParam(value = "firstName") String firstName, @RequestParam String lastName,
			@RequestParam int departmentId) {
		logger.info("In employee search {}", firstName);
		return ResponseEntity.ok(employeeService.findByFirstNameORDepartmentId(firstName, lastName, departmentId));

	}
	
	/**
	 * 
	 * @param firstName
	 * @param lastName
	 * @param departmentId
	 * @param offset
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */

	@GetMapping("/employee/searchby")
	public List<Employee> findByFirstNameORDepartmentIdORLastName(@RequestParam(value = "firstName") String firstName,
			@RequestParam String lastName, @RequestParam int departmentId, @RequestParam int offset,
			@RequestParam int pageSize, @RequestParam String sortBy, String sortDir) {

		Sort sort = null;
		if (sortDir.equalsIgnoreCase("asc")) {
			sort = Sort.by(sortBy).ascending();
		} else {
			sort = Sort.by(sortBy).descending();
		}
		Pageable p = PageRequest.of(offset, pageSize, sort);
		logger.info("In employee search {}", firstName);
		return employeeService.findByFirstNameORDepartmentIdORLastName(firstName, lastName, departmentId, p);

	}

	/**
	 * 
	 * @param employeeId
	 * @return
	 */

	@DeleteMapping("/employee/{employeeId}")
	public ResponseEntity<String> deleteEmployeeDetails(@PathVariable int employeeId) {
		logger.info("In delete employee:{}", employeeId);

		return ResponseEntity.ok(employeeService.deleteEmployeeDetails(employeeId));
	}

	/**
	 * 
	 * @param employeeDto
	 * @param employeeId
	 * @return
	 */

	@PatchMapping("/employee/{employeeId}")
	public ResponseEntity<EmployeeDTO> updateEmployeeDetails(@Valid @RequestBody EmployeeDTO employeeDto,
			@PathVariable int employeeId) {
		logger.info("In update employee:{}", employeeId);

		return ResponseEntity.ok(employeeService.updateEmployeeDetails(employeeDto, employeeId));

	}

}
