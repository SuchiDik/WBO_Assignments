package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Pageable;

import com.example.customexception.ResourceNotFoundException;
import com.example.demo.entities.Employee;
import com.example.demo.entities.EmployeeDTO;
import com.example.demo.entities.EmployeeDtoConverter;
import com.example.demo.repository.EmployeePaginationRepository;

public class EmployeeService {

	Logger logger = LoggerFactory.getLogger(EmployeeService.class);
	private final EmployeePaginationRepository empRepository;

	private final EmployeeDtoConverter employeeDtoConverter;

	public EmployeeService(EmployeePaginationRepository empRepository, EmployeeDtoConverter employeeDtoConverter) {
		this.employeeDtoConverter = employeeDtoConverter;
		this.empRepository = empRepository;
	}
	
	public EmployeeDTO saveEmployeeDetails(EmployeeDTO employeeDto) {
		Employee employee = employeeDtoConverter.convertDtoToEntity(employeeDto);
		employee = empRepository.save(employee);
		return employeeDtoConverter.convertEntityToDto(employee);
	}

	@Cacheable(cacheNames = "employee", key = "#employeeId")
	public Employee findByEmployeeId(int employeeId) {
		logger.info("In a get employee by id");
		return empRepository.findByEmployeeId(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "Id", employeeId));

	}

	@CacheEvict(cacheNames = "employee", key = "#employeeId")
	public String deleteEmployeeDetails(int employeeId) {

		empRepository.deleteById(employeeId);
		return "Employee Deleted : " + employeeId;
	}

	@CachePut(cacheNames = "employee", key = "#employeeId")
	public EmployeeDTO updateEmployeeDetails(EmployeeDTO employeeDto, int employeeId) {
		Employee employee = employeeDtoConverter.convertDtoToEntity(employeeDto);
		employee = empRepository.findByEmployeeId(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "Id", employeeId));

		employee.setCurrentLocation(employeeDto.getCurrentLocation());
		employee.setEmail(employeeDto.getEmail());
		employee.setFirstName(employeeDto.getFirstName());
		employee.setLastName(employeeDto.getLastName());
		employee.setMiddleName(employeeDto.getMiddleName());
		employee.setPhoneNo(employeeDto.getPhoneNo());
		employee.setDateOfBirth(employeeDto.getDateOfBirth());
		employee.setDepartmentId(employeeDto.getDepartmentId());
		employee.setDesignation(employeeDto.getDesignation());
		employee.setJoiningDate(employeeDto.getJoiningDate());
		employee.setGender(employeeDto.getGender());
		employee.setLastPromotionDate(employeeDto.getLastPromotionDate());
		employee.setLastWorkingDate(employeeDto.getLastWorkingDate());
		employee.setManagerId(employeeDto.getManagerId());
		employee.setProjectAllocationDate(employeeDto.getProjectAllocationDate());
		employee.setResignedDate(employeeDto.getResignedDate());
		employee.setProjectId(employeeDto.getProjectId());
		employee.setSalary(employeeDto.getSalary());
		employee.setTotalExp(employeeDto.getTotalExp());

		employee = empRepository.save(employee);
		return employeeDtoConverter.convertEntityToDto(employee);

	}

	public List<Employee> getEmployeeDetails() {
		return (List<Employee>) empRepository.findAll();
	}

	public Optional<Employee> findByFirstNameORDepartmentId(String firstName, String lastName, int departmentId) {
		logger.info("In a get employee by firstName,lastName and DepartmentId");
		logger.info("In employee search {}", firstName);
		return empRepository.findByFirstNameORDepartmentId(firstName, lastName, departmentId);

	}

	public List<Employee> findByFirstNameORDepartmentIdORLastName(String firstName, String lastName, int departmentId,
			Pageable p) {
		List<Employee> empPage = this.empRepository.findByFirstNameORDepartmentIdORLastName(firstName, lastName,
				departmentId, p);
		logger.info("In a get employee by firstName,lastName and DepartmentId");
		return empPage;
	}

}