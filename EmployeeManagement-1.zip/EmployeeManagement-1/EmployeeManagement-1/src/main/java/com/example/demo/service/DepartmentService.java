package com.example.demo.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import com.example.customexception.ResourceNotFoundException;
import com.example.demo.entities.Department;
import com.example.demo.entities.DepartmentDTO;
import com.example.demo.entities.DepartmentDtoConverter;
import com.example.demo.repository.DepartmentRepository;

public class DepartmentService {

	Logger logger = LoggerFactory.getLogger(DepartmentService.class);

	private final DepartmentRepository departmentRepository;

	private final DepartmentDtoConverter departmentDtoConverter;

	public DepartmentService(DepartmentRepository departmentRepository, DepartmentDtoConverter departmentDtoConverter) {
		this.departmentRepository = departmentRepository;
		this.departmentDtoConverter = departmentDtoConverter;
	}

	@Cacheable(cacheNames = "department", key = "#departmentId")
	public Department findByDepartmentId(int departmentId) {
		return departmentRepository.findByDepartmentId(departmentId)
				.orElseThrow(() -> new ResourceNotFoundException("Department", "Id", departmentId));
	}

	public DepartmentDTO saveDepartmentDetails(DepartmentDTO departmentDto) {
		Department department = departmentDtoConverter.convertDtoToEntity(departmentDto);
		department = departmentRepository.save(department);
		return departmentDtoConverter.convertEntityToDto(department);
	}

	@CacheEvict(cacheNames = "department", key = "#departmentId")
	public String deleteDepartmentDetails(int departmentId) {

		departmentRepository.deleteById(departmentId);
		return "dept Deleted : " + departmentId;
	}

	@CachePut(cacheNames = "department", key = "#departmentId")
	public DepartmentDTO updateDepartmentDetails(DepartmentDTO deptDto, int departmentId) {
		Department department = departmentDtoConverter.convertDtoToEntity(deptDto);
		department = departmentRepository.findByDepartmentId(departmentId)
				.orElseThrow(() -> new ResourceNotFoundException("Department", "Id", departmentId));
		logger.info("In aupdate dept by id");
		department.setDepartmentHeadName(deptDto.getDepartmentHeadName());
		department.setDepartmentName(deptDto.getDepartmentName());
		department = departmentRepository.save(department);
		return departmentDtoConverter.convertEntityToDto(department);

	}

	public List<Department> getDepartmentDetails() {
		return departmentRepository.findAll();
	}
}