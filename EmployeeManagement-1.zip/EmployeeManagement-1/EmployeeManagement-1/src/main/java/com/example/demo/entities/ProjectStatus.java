package com.example.demo.entities;

public enum ProjectStatus {
	
	ACTIVE,ONHOLD,COMPLETED

}
