package com.example.demo.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.annotations.SQLDelete;
import org.springframework.format.annotation.DateTimeFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@SQLDelete(sql = "UPDATE employee SET deleted=true WHERE employeeId=?")
@Table(name = "employee")
public class Employee

{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotNull
	@Size(min = 10, message = "employee Id can not empty")
	private int employeeId;

	@Size(min = 10, message = "First Name can not empty")
	@NotNull
	@Column
	private String firstName;

	@Size(min = 10, message = "Middle name can not empty")
	@NotNull
	@Column
	private String middleName;

	@Size(min = 10, message = "last can not empty")
	@NotNull
	@Column
	private String lastName;

	@Column
	@NotNull
	@Email
	private String email;

	@Column
	@NotNull
	private String phoneNo;
	@Column
	@NotNull
	private String gender;

	@DateTimeFormat
	@Column
	private Date dateOfBirth;

	@DateTimeFormat
	private Date joiningDate;

	@Column
	private Integer totalExp;

	@Column
	@Min(20)
	private String currentLocation;

	@Column
	@Min(20)
	private String salary;

	@Column
	@Min(20)
	private String designation;

	@DateTimeFormat
	private Date lastPromotionDate;

	@DateTimeFormat
	private Date projectAllocationDate;

	@DateTimeFormat
	private Date resignedDate;

	@DateTimeFormat
	private Date lastWorkingDate;

	@Column
	@Min(20)
	private Integer managerId;

	private int departmentId;

	private int projectId;

	private boolean deleted = Boolean.FALSE;

	public Employee(int employeeId, String firstName, String middleName, String lastName, String email) {

		this.employeeId = employeeId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.email = email;

	}

	public boolean isEmpty() {

		return false;
	}

}
