package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.demo.entities.DepartmentDtoConverter;
import com.example.demo.entities.EmployeeDtoConverter;
import com.example.demo.entities.ProjectDtoConverter;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeePaginationRepository;
import com.example.demo.repository.ProjectRepository;
import com.example.demo.service.DepartmentService;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.ProjectService;

@Configuration
public class BeanConfigurations {

	@Bean
	public DepartmentService departmentService(DepartmentRepository departmentRepository,DepartmentDtoConverter departmentDtoConverter) {
		return new DepartmentService(departmentRepository,departmentDtoConverter);
	}

	@Bean
	public EmployeeService employeeService(EmployeePaginationRepository empRepository,EmployeeDtoConverter employeeDtoConverter) {
		return new EmployeeService(empRepository,employeeDtoConverter);
	}

	@Bean
	public ProjectService projectService(ProjectRepository projectRepository,ProjectDtoConverter projectDtoConverter) {
		return new ProjectService(projectRepository,projectDtoConverter);
	}
	
	
}
