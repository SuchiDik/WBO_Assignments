package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.Department;
import com.example.demo.entities.DepartmentDTO;
import com.example.demo.entities.DepartmentDtoConverter;
import com.example.demo.service.DepartmentService;

@RestController
@RequestMapping("/api/v1")
public class DepartmentController {

	private DepartmentService departmentService;
	private DepartmentDtoConverter departmentdtoConverter;

	public DepartmentController(DepartmentService departmentService,DepartmentDtoConverter departmentdtoConverter) {
		this.departmentService = departmentService;
		this.departmentdtoConverter=departmentdtoConverter;
	}

	Logger logger = LoggerFactory.getLogger(DepartmentController.class);

	@GetMapping(path = "/departments")
	public ResponseEntity<List<Department>> getDepartmentDetails() {
		logger.debug("find all");
		return ResponseEntity.ok(departmentService.getDepartmentDetails());

	}

	@PostMapping(path = "/department", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<DepartmentDTO> saveDepartmentDetails(@Valid @RequestBody DepartmentDTO departmentDTO) {
		logger.info("In save dept");
		return new ResponseEntity<>(departmentService.saveDepartmentDetails(departmentDTO), HttpStatus.CREATED);
	}

	@GetMapping("/department/{departmentId}")
	public ResponseEntity<Department> findByDepartmentId(@PathVariable int departmentId) {
		logger.info("In get deptController:{}", departmentId);
		return ResponseEntity.ok(departmentService.findByDepartmentId(departmentId));

	}

	@DeleteMapping("/department/{departmentId}")
	public ResponseEntity<String> deleteDepartmentDetails(@PathVariable int departmentId) {
		logger.info("In delete department:{}", departmentId);

		return ResponseEntity.ok(departmentService.deleteDepartmentDetails(departmentId));
	}

	@PatchMapping("/department/{departmentId}")
	public ResponseEntity<DepartmentDTO> updateDepartmentDetails(@Valid @RequestBody DepartmentDTO deptDto,
			@PathVariable int departmentId) {
		logger.info("In update dept:{}", departmentId);

		return ResponseEntity.ok(departmentService.updateDepartmentDetails(deptDto, departmentId));

	}

}
