package com.example.demo.entities;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "project")
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Project {

	@Id
	@Column
	@NotNull
	private Integer projectId;

	@Column
	private String projectName;

	@Column
	private String clientName;

	@DateTimeFormat
	private Date projectStartDate;

	@DateTimeFormat
	private Date lastPromotionDate;

	private ProjectStatus status;

	public Project(int projectId, String projectName, String clientName) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.clientName = clientName;
	}

}
