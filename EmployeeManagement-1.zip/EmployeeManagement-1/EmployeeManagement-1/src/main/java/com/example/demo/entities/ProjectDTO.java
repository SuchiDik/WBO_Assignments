package com.example.demo.entities;

import java.sql.Date;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Component
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ProjectDTO {

	private Integer projectId;
	private String projectName;
	private String clientName;
	private Date projectStartDate;
	private Date lastPromotionDate;
	private ProjectStatus status;

}
