package com.example.demo.entities;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class ProjectDtoConverter {

	public ProjectDTO convertEntityToDto(Project project) {
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(project, ProjectDTO.class);
	}

	public Project convertDtoToEntity(ProjectDTO projectDTO) {
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(projectDTO, Project.class);
	}

}
