package com.example.demo.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.entities.Department;
import com.example.demo.entities.Project;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.service.DepartmentService;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(locations = "/test-case.xml")
class DepartmentServiceTest {

	@MockBean
	DepartmentRepository deptRepository;

	@Test
	void testsaveDepartmentDetails() {
		Department dept = new Department();
		dept.setDepartmentName("Education");
		Mockito.doReturn(dept).when(deptRepository).save(dept);

		assertEquals("Education", deptRepository.save(dept).getDepartmentName());
	}

	@Test
	void testdeleteDepartmentDetails() {
		Department dept = new Department();
		dept.setDepartmentName("Education");
		dept.setDepartmentHeadName("suchita");
		dept.setDepartmentId(1);
		Mockito.when(deptRepository.existsById(dept.getDepartmentId())).thenReturn(false);

		assertFalse(deptRepository.existsById(dept.getDepartmentId()));
	}

	@Test
	void testfindByProjectId() {
		Department department = new Department(1, "Education", "suchita");
		Mockito.when(deptRepository.findByDepartmentId(1)).thenReturn(Optional.of(department));
		assertEquals(1, deptRepository.findByDepartmentId(1).get().getDepartmentId());

	}

	@Test
	void testgetDepartmentDetails() {
		List<Department> deptList = new ArrayList<>();
		Department dept = new Department();
		deptList.add(dept);
		Mockito.doReturn(deptList).when(deptRepository).findAll();

		assertEquals(1, ((List<Department>) deptRepository.findAll()).size());
	}
}
