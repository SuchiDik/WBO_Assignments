package com.example.demo;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories(basePackages = "com.example.*")
//@ContextConfiguration(locations = "/test-case.xml")
class EmployeeManagement1ApplicationTests {

	

}
