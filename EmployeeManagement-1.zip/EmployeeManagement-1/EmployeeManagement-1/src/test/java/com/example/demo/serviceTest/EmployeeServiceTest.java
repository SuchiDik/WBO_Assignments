package com.example.demo.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.demo.entities.Employee;
import com.example.demo.repository.EmployeePaginationRepository;
import com.example.demo.service.EmployeeService;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(locations = "/test-case.xml")
class EmployeeServiceTest {
	@MockBean
	EmployeePaginationRepository empRepository;

	@Autowired
	EmployeeService empService;

	@Test
	void testsaveEmployeeDetails() {
		Employee emp = new Employee();
		emp.setFirstName("suchita");
		Mockito.doReturn(emp).when(empRepository).save(emp);

		assertEquals("suchita", empRepository.save(emp).getFirstName());
	}

	@Test
	void testfindByEmployeeId() {

		Employee employee = new Employee(1, "suchita", "abhimanyu", "bedre", "abc@gmail.com");
		Mockito.when(empRepository.findByEmployeeId(1)).thenReturn(Optional.of(employee));
		assertEquals(1, empRepository.findByEmployeeId(1).get().getEmployeeId());

	}

	@Test
	void testdeleteEmployeeDetails() {
		Employee emp = new Employee();
		emp.setFirstName("suchita");
		emp.setLastName("bedre");
		emp.setMiddleName("A");
		emp.setEmail("suchita@gmail.com");
		Mockito.when(empRepository.existsById(emp.getEmployeeId())).thenReturn(false);
		assertFalse(empRepository.existsById(emp.getEmployeeId()));
	}

	@Test
	void testgetEmployeeDetails() {
		List<Employee> empList = new ArrayList<>();
		Employee emp = new Employee();
		empList.add(emp);
		Mockito.doReturn(empList).when(empRepository).findAll();

		assertEquals(1, ((List<Employee>) empRepository.findAll()).size());
	}
}