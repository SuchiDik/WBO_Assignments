package com.example.demo.serviceTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.entities.Employee;
import com.example.demo.entities.Project;
import com.example.demo.repository.ProjectRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(locations = "/test-case.xml")
class ProjectServiceTest {
	@MockBean
	ProjectRepository projectRepository;

	@Test
	void testsaveProjectDetails() {
		Project project = new Project();
		project.setProjectName("Education");
		Mockito.doReturn(project).when(projectRepository).save(project);

		assertEquals("Education", projectRepository.save(project).getProjectName());
	}
	
	@Test
	void testdeleteProjectDetails() {
		Project project = new Project();
		project.setProjectName("Education");
		project.setClientName("suchita");
		Mockito.when(projectRepository.existsById(project.getProjectId())).thenReturn(false);
		assertFalse(projectRepository.existsById(project.getProjectId()));
	}

	@Test
	void testfindByProjectId() {		
			Project project = new Project(1, "Education","suchita");
		    Mockito.when(projectRepository.findByProjectId(1)).thenReturn(Optional.of(project));
			assertEquals("suchita", projectRepository.findByProjectId(1).get().getClientName());

		}

	@Test
	void testgetProjectDetails() {
		List<Project> projectList = new ArrayList<>();
		Project project = new Project();
		projectList.add(project);
		Mockito.doReturn(projectList).when(projectRepository).findAll();
		assertEquals(1, ((List<Project>) projectRepository.findAll()).size());
	}
}
